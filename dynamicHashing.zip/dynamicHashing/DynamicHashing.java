package dynamicHashing;

public class DynamicHashing {
	private int bits;
	private int globalIdentity;
	private int numberOfBuckets;
	private int sizeOfBucket;
	private Bucket bucketArray[];
	private BinaryConversion binaryConversion;
	
	public DynamicHashing(int bits, int sizeOfBucket){
		this.bits = bits;
		this.sizeOfBucket = sizeOfBucket;
		globalIdentity = 0;
		numberOfBuckets = (int)Math.pow(2, bits);
		bucketArray = new Bucket[1];
		bucketArray[0] = new Bucket("");
		binaryConversion = new BinaryConversion();
	}
	public int h(int num){
		return num % numberOfBuckets;
	}
	
	public void insert(int num){
		int index = h(num);
		String id = binaryConversion.decToBin(index, bits).substring(0, globalIdentity);//get binary representation of hash of length
																	//same as global I
		if(globalIdentity == 0){	//If global I is 0, then ID will null string, can't convert to int to find out index
			if(sizeOfBucket == bucketArray[0].getSize()){
				redistribute(num, bucketArray,0);
			}
			else
				bucketArray[0].insertInBucket(num);
		}
		else{
			index = binaryConversion.binToDec(id);
			if(sizeOfBucket == bucketArray[index].getSize()){
				redistribute(num, bucketArray,index);
			}
			else
				bucketArray[index].insertInBucket(num);
		}
	}
	public void redistribute(int num, Bucket[] oldBucket, int index){
		if(globalIdentity == oldBucket[index].getI()){
			globalIdentity++;
			if (globalIdentity > bits){
				System.err.println("Overflow Detected");
				globalIdentity--;
				return;
			}
			//noOfBuckets = (int)Math.pow(2, identity);
			Bucket[] newBucket = new Bucket[(int)Math.pow(2, globalIdentity)];	//double bucket size and replace 1 entry with 2
			for(int i = 0, j =0 ; i < (int)Math.pow(2, globalIdentity); i+=2, j++){
				newBucket[i] = newBucket[i+1] = oldBucket[j];
			}
			String idx = oldBucket[index].getHeader();
			String index1 = idx + "0";
			String index2 = idx + "1";
			newBucket[binaryConversion.binToDec(index1)] = new Bucket(index1);
			newBucket[binaryConversion.binToDec(index2)] = new Bucket(index2);
			for(int i = 0 ; i < oldBucket[index].getSize(); i++){	//redistribute the new buckets
				int temp = oldBucket[index].getBucketContent(i);
				newBucket[binaryConversion
				        .binToDec(binaryConversion.decToBin(h(temp), bits)
				        		.substring(0, globalIdentity))].insertInBucket(temp);
			}
			bucketArray = newBucket;
			insert(num);
		}
		else if(globalIdentity > oldBucket[index].getI()){
			int lowerLimit = 0;
			int upperLimit = (int)Math.pow(2, globalIdentity)-1;	//find the middle point of indices that point to same bucket
			for(int i = index; i >= 0; i--){
				if(oldBucket[index] != oldBucket[i]){
					lowerLimit = i+1;
					break;
				}
			}
			for(int i = index; i < (int)Math.pow(2, globalIdentity) ; i++){
				if(oldBucket[index] != oldBucket[i]){
					upperLimit = i-1;
					break;
				}
			}
			int middle = (int)Math.ceil((upperLimit + lowerLimit)/2.0);
			String idx = oldBucket[index].getHeader();	//redistribute the buckets to newly found bucket
			String index1 = idx + "0";
			String index2 = idx + "1";
			Bucket newBucket1 = new Bucket(index1);
			Bucket newBucket2 = new Bucket(index2);
			for(int i = 0 ; i < oldBucket[index].getSize(); i++){
				int temp = oldBucket[index].getBucketContent(i);
				int tempH = h(temp);
				String tempHBin = binaryConversion.decToBin(tempH, bits);
				if(index2.equals(tempHBin.substring(0, index2.length()))){
					newBucket2.insertInBucket(temp);
				}
				else{
					newBucket1.insertInBucket(temp);
				}
			}
			for(int i = lowerLimit ; i < middle ; i++) bucketArray[i] = newBucket1;
			for(int i = middle; i <= upperLimit; i++) bucketArray[i] = newBucket2;
			insert(num);
		}
		else{
			System.err.println("Error detected");
		}
	}
	
	public void show(){
		System.out.println("["+ globalIdentity+"]:");
		for(int i = 0 ; i < (int)Math.pow(2,globalIdentity); i++){
			Bucket bucket = bucketArray[i];
			if(i != 0 && bucket == bucketArray[i-1]) continue;
			//System.out.println("["+i+"]:");
			
			System.out.print("bucket (" + bucket.getHeader() + "): ");
			System.out.println("["+ bucket.getHeader().length()+ "]");
			for(int j = 0 ; j < bucket.getSize() ; j++){
				System.out.println(bucket.getBucketContent(j));
				
			}
		}
	}
}
